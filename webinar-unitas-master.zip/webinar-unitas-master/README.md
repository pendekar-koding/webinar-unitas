# webinar-unitas

Database postgreSQL
nama database = webinar_unitas

 running = mvn spring-boot:run
 
 build .jar = mvn assembly:assembly
