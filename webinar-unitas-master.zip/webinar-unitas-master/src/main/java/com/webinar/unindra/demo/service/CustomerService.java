package com.webinar.unindra.demo.service;

import com.webinar.unindra.demo.common.service.CommonService;
import com.webinar.unindra.demo.wrapper.CustomerWrapper;

public interface CustomerService extends CommonService<CustomerWrapper, Long> {
}
