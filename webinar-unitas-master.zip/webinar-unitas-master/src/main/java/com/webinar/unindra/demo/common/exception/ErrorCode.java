package com.webinar.unindra.demo.common.exception;

public enum ErrorCode {
    GENERIC_FAILURE
}
