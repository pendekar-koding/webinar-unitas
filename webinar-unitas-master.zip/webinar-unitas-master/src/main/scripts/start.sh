#!/usr/bin/env bash
java -jar lib/webinar-unindra.jar --spring.config=../config/application.properties